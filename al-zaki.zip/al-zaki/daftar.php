<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To Do List</title>
</head>
<body>
    <h1>Daftar</h1>
    <form action="proses-daftar.php" method="POST">
        <label for="name">name :</label> <br>
        <input type="text" name="name" id="name"> <br> <br>
        <label for="username">username :</label> <br>
        <input type="text" name="username" id="username"> <br> <br>
        <label for="email">Email :</label> <br>
        <input type="email" name="email" id="email"> <br> <br>
        <label for="password">Password :</label> <br>
        <input type="password" name="password" id="password"> <br> <br>
        <label for="birth_date">Birth Date :</label> <br>
        <input type="date" name="birth_date" id="birth_date"> <br> <br>
        <button type="submit">Daftar</button>
    </form>
</body>
</html>