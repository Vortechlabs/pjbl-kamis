<?php
session_start();
include 'koneksi.php';

if(!isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == false){
    header("Location: login.php");
    exit;
}
$id_todo = $_GET['id'];

$sqlToDo = "SELECT todo.*, category.* FROM todo JOIN category ON todo.id_category = category.id_category WHERE id_todo = '$id_todo'";
$todos = mysqli_query($conn, $sqlToDo);
$todo = mysqli_fetch_assoc($todos);

$sqlCategory = "SELECT * FROM category";
$category = mysqli_query($conn, $sqlCategory);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To Do List</title>
</head>
<body>
    <h1>Update ToDoList</h1>
    <form action="proses-edit.php" method="POST">
        <div class="form-group">
            <label for="title">Title :</label><br>
            <?php
               
                    echo '<input type="text" name="title" id="title" value="'.$todo['title'].'">';
        
            ?>
        </div> <br> <br>
        <div class="form-group">
            <label for="description">Description :</label><br>
            <?php
                    echo '<input type="text" name="description" id="description" value="'.$todo['description'].'">';
            ?>
        </div> <br> <br>
        <div class="form-group">
            <label for="status">Status :</label><br>
            <select name="status" id="status">
                <?php
                    echo '<option value="'.$todo['status'].'">'.$todo['status'].'</option>';
                ?>
                <option value="pending">Pending</option>
                <option value="done">Done</option>
            </select>
        </div> <br> <br>
        <div class="form-group">
            <label for="category">Category :</label><br>
            <select name="category" id="category">
                <?php
                echo '<option value="'.$todo['id_category'].'">'.$todo['category'].'</option>';
                while($row = mysqli_fetch_assoc($category)){
                    echo "<option value=".$row['id_category'].">".$row['category']."</option>";
                }
                ?>
            </select>
        </div> <br> <br>

        <button type="submit">Update ToDoList</button>
    </form>
</body>
</html>