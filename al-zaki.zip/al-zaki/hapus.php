<?php
session_start();
include 'koneksi.php';

if(!isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == false){
    header("Location: login.php");
    exit;
}
$id_todo = $_GET['id'];

$sql = "DELETE FROM todo WHERE id_todo = '$id_todo'";
$query = mysqli_query($conn, $sql);

if($query){
    header("Location: ./index.php?message=delete_success");
    exit;
}else{
    header("Location: ./index.php?message=delete_failed");
    exit;
}
?>