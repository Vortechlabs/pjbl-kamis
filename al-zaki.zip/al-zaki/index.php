<?php
session_start();
include 'koneksi.php';

$id_user = $_SESSION['id_user'];
    if(!isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == false){
        header("Location: login.php");
        exit;
    }

    $sql = 'SELECT todo.*, category.* FROM todo JOIN category ON todo.id_category = category.id_category';
    $result = mysqli_query($conn, $sql);
    
    $sqlCategory = "SELECT * FROM category";
    $category = mysqli_query($conn, $sqlCategory);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To Do List</title>
    <style>
        *{
            font-family: "Futura Md BT";
            padding: 0;
            margin: 0;
        }
        main{
            padding: 1rem;
            display: grid;
            row-gap: 1rem;
            justify-content: center;
        }

        nav{
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #3a3a3aff;
            color: white;
            padding: 1rem;
        }
        .menu-container{
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        .menu{
            text-decoration: none;
            color: white;
        }
        button{
            display: flex;
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 0.2rem;
        }
        .primary-btn{
            background: blue;
            color: white;
        }
        .success-btn{
            background: green;
            color: white;
        }
        .danger-btn{
            background: red;
            color: white;
        }
        a{
            text-decoration: none;
        }
        .card-container{
            display: grid;
            grid-template-columns: auto auto auto;
            width: 100%;
            gap: 1rem;
        }
        .card{
            display: grid;
            row-gap: 1rem;
            background: #272727ff;
            padding: 1rem;
            border-radius: 0.5rem;
            color: white;
            min-width: 20rem;
        }
        select{
            width: 50%;
            padding: 0.2rem;
            border: none;
            background: #fafafaff;
            border-radius: 0.2rem;
        }

    </style>
</head>
<body>
    <nav>
        <h2>ToDoList</h2>


        <?php
        if($id_user){
            echo '<div class="menu-container">';
            echo '<a href="" class="menu">profil</a>';
            echo '<a href="logout.php" class="menu">logout</a>';
            echo '</div>';
        }else{
            echo '<div>';
            echo '<a href="login.php" class="menu">login</a>';
            echo '</div>';
        }
        ?>
    </nav>

    <main>
        <center>
    <form>
        <label for="filter">Filter Kategori :</label>
        <select name="filter" id="filter">
            <option value="semua">Semua</option>
            <?php
                while($row = mysqli_fetch_assoc($category)){
                    echo "<option value=".$row['id_category'].">".$row['category']."</option>";
                }
            ?>
        </select>
    </form>
    </center>
    
        <center style="display: flex; gap: 1rem; justify-content: center;">
    <a href="tambah.php">
        <button class="success-btn">[+] Tambah</button>
    </a>
    <a href="tambah.php">
        <button class="primary-btn" onclick=(window.print())>[+] Print</button>
    </a>
    </center>

    <div class="card-container">
        <?php
        while($row = mysqli_fetch_assoc($result)) {
            echo "<div class='card'>";
            echo "<h1>".$row['title']."</h1>";
            echo "<p>".$row['description']."</p>";
            echo "<p>Kategori : ".$row['category']."</p>";
            echo "<p>Status : ".$row['status']."</p>";
            echo '<div style="display: flex; gap: 1rem; margin-top: 1rem;">';
            echo '<a href="edit.php?id='.$row['id_todo'].'"><button class="primary-btn">Edit</button></a>';
            echo '<a href="hapus.php?id='.$row['id_todo'].'"><button class="danger-btn">Hapus</button></a>';
            echo '</div>';
            echo "</div>";
        };
        ?>
    </div>

    
        <div>
        <a href="" class="menu">profil</a>                  
        </div>
</main>

</body>
</html>