<?php
$host = "localhost";
$user = "root";
$password = "";
$db_name = "db_todo_app";

$conn = mysqli_connect($host, $user, $password, $db_name);

// if($conn){
//     echo "berhasil";
// }else{
//     "Gagal";
// }
?>