<?php
session_start();
include 'koneksi.php';

if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == true){
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To Do List</title>
</head>
<body>
    <h1>Login</h1>
    <form action="proses-login.php" method="POST">
        <label for="username">username :</label> <br>
        <input type="text" name="username" id="username"> <br> <br>
        <label for="password">Password :</label> <br>
        <input type="text" name="password" id="password"> <br> <br>
        <button type="submit">Login</button>
    </form>
</body>
</html>