<?php
include 'koneksi.php';

$username = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$email = $_POST['email'];
$name = $_POST['name'];
$birth_date = $_POST['birth_date'];


$sql = "INSERT INTO user (username, password, email, name, birth_date)
        VALUES ('$username', '$password', '$email', '$name', '$birth_date')";
$query = mysqli_query($conn, $sql);

if($query){
    header("Location: login.php?message=success_register");
    exit;
}else{
    header("Location: daftar.php?message=failed_register");
    exit;
}
?>