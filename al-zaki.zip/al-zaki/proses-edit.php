<?php
session_start();
include 'koneksi.php';

if(!isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == false){
    header("Location: login.php");
    exit;
}

$id_todo = $_GET['id'];
$title = $_POST['title'];
$description = $_POST['description'];
$status = $_POST['status'];
$id_category = $_POST['category'];
$id_user = '1';

$sql = "UPDATE `todo` SET `title` = '$title', `description` = '$description', `status` ='$status', `id_category` = '$id_category', `id_user` = '$id_user', `created_at` = NOW(), `updated_at` = NOW() WHERE `todo`.`id_todo` = '$id_todo'";
$query = mysqli_query($conn, $sql);

if($query){
    header("Location: ./index.php?message=success");
    exit;
}else{
    header("Location: ./daftar.php?message=failed");
    exit;
}
?>