<?php
session_start();
include 'koneksi.php';

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM user WHERE username = '$username' LIMIT 1";
$query = mysqli_query($conn, $sql);

if(mysqli_num_rows($query) == 0){
    header("Location: login.php?message=username_notfound");
    exit;
}

$user = mysqli_fetch_assoc($query);

if(password_verify($password, $user['password'])){
    $_SESSION['id_user'] = $user['id_user'];
    $_SESSION['logged_in'] = true;

    header("Location: index.php?message=login_berhasil");
    exit;
}else{

    header("Location: login.php?message=password_salah");
    exit;
}
?>