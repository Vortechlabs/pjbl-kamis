<?php
session_start();
include 'koneksi.php';

if(!isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == false){
    header("Location: login.php");
    exit;
}

$title = $_POST['title'];
$description = $_POST['description'];
$status = $_POST['status'];
$id_category = $_POST['category'];
$id_user = '1';

$sql = "INSERT INTO todo (title, description, status, id_category, id_user, created_at, updated_at)
        VALUES ('$title', '$description', '$status', '$id_category', '$id_user', NOW(), NOW())";
$query = mysqli_query($conn, $sql);

if($query){
    header("Location: ./index.php?message=success");
    exit;
}else{
    header("Location: ./daftar.php?message=failed");
    exit;
}
?>