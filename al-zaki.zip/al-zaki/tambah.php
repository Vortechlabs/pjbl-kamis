<?php
session_start();
include 'koneksi.php';

if(!isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == false){
    header("Location: login.php");
    exit;
}

$sql = 'SELECT * FROM category';
$category = mysqli_query($conn, $sql);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To Do List</title>
        <style>
        *{
            font-family: "Futura Md BT";
            padding: 0;
            margin: 0;
        }
        body{
            background: #eeeeeeff;
        }
        main{
            padding: 1rem;
            display: grid;
            row-gap: 1rem;
            justify-content: center;
            height: 100%;
        }
        form{
            background: white;
            padding: 2rem;
            min-width: 100%;
        }
        form h1{
            margin-bottom: 1rem;
            text-align: center;
        }
        input{
            width: 100%;
        }
        nav{
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #3a3a3aff;
            color: white;
            padding: 1rem;
        }
        .menu-container{
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        .menu{
            text-decoration: none;
            color: white;
        }
        button{
            display: flex;
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 0.2rem;
            width: 100%;
            text-align: center;
        }
        .primary-btn{
            background: blue;
            color: white;
        }
        .success-btn{
            background: green;
            color: white;
            text-align: center;
        }
        .danger-btn{
            background: red;
            color: white;
        }
        a{
            text-decoration: none;
        }
        .card-container{
            display: grid;
            grid-template-columns: auto auto auto;
            width: 100%;
            gap: 1rem;
        }
        .card{
            display: grid;
            row-gap: 1rem;
            background: #272727ff;
            padding: 1rem;
            border-radius: 0.5rem;
            color: white;
            min-width: 20rem;
        }
        select{
            width: 100%;
            padding: 0.2rem;
            border: none;
            background: #fafafaff;
            border-radius: 0.2rem;
        }

    </style>
</head>
<body>
    <nav>
        <h2>ToDoList</h2>
        <div class="menu-container">
            <a href="" class="menu">profil</a>
            <a href="" class="menu">logout</a>
        </div>
        <div>
            <a href="" class="menu">login</a>
        </div>
    </nav>

    <main>
        <div>
    <form action="proses-tambah.php" method="POST">
    <h1>Tambah ToDoList</h1>
        <div class="form-group">
            <label for="title">Title :</label><br>
            <input type="text" name="title" id="title">
        </div> <br> <br>
        <div class="form-group">
            <label for="description">Description :</label><br>
            <input type="text" name="description" id="description">
        </div> <br> <br>
        <div class="form-group">
            <label for="status">Status :</label><br>
            <select name="status" id="status">
                <option value="pending">Pending</option>
                <option value="done">Done</option>
            </select>
        </div> <br> <br>
        <div class="form-group">
            <label for="category">Category :</label><br>
            <select name="category" id="category">
                <?php
                while($row = mysqli_fetch_assoc($category)){
                    echo "<option value=".$row['id_category'].">".$row['category']."</option>";
                }
                ?>
            </select>
        </div> <br> <br>

        <center><button type="submit" class="success-btn">Create ToDoList</button></center>
    </form>
    </div>
    </main>
</body>
</html>